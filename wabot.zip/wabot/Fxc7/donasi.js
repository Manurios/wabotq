const donasi = (name) => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ *DONASI SEIKHLASNYA:)* ❉⊰━━✿
┃  
┣━⊱ *GOPAY*
┣⊱ 083141926935
┣━⊱ *PULSA*
┣⊱ 083141926935
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY ${name}*
┗━━━━━━━━━━━━━━━━━━━━

`
}
exports.donasi = donasi